/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppart1;


/**
 *
 * @author Student
 */
   

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // USER DETAILS
        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        login user = new login(firstName, lastName);

        // ================= USERNAME =================
        String username;
        while (true) {
            System.out.print("Enter username: ");
            username = input.nextLine();

            String message = user.registerUsername(username);
            System.out.println(message);

            if (user.checkUserName(username)) {
                break;
            }
        }

        // ================= PASSWORD =================
        String password;
        while (true) {
            System.out.print("Enter password: ");
            password = input.nextLine();

            String message = user.registerPassword(password);
            System.out.println(message);

            if (user.checkPasswordComplexity(password)) {
                break;
            }
        }

        // ================= PHONE NUMBER =================
        String phone;
        while (true) {
            System.out.print("Enter phone number (e.g. +27831234567): ");
            phone = input.nextLine();

            String message = user.registerCellPhoneNumber(phone);
            System.out.println(message);

            if (user.checkCellPhoneNumber(phone)) {
                break;
            }
        }

        // ================= LOGIN =================
        System.out.println("\n--- LOGIN ---");

        while (true) {
            System.out.print("Enter username: ");
            String loginUser = input.nextLine();

            System.out.print("Enter password: ");
            String loginPass = input.nextLine();

            String message = user.returnLoginStatus(loginUser, loginPass);
            System.out.println(message);

            if (user.loginUser(loginUser, loginPass)) {
                break;
            }
        }

        input.close();
    }  
    
    Scanner scanner = new Scanner(System.in);
    
  boolean loggedInPart2 = true; // controls the application loop
  
    while(loggedInPart2); {
    
        // Display meun options to the user
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
  
         // read user input here
        System.out.println("Choose an option: ");
        int choice = 0;
        int choice = scanner.nextln(); // choice = scanner.nextInt(); -- logic goes here
  
        switch (choice){
            case 1:
                System.out.println("Launching send message feature...");// lauch send message feature -- logic goes here
                break;
                
            case 2:
                System.out.print("Coming soon."); // display 'Coming Soon.' -- logic goes here
                break;
                
            case 3:
                System.out.println("Application closing...");
                loggedInPart2 = false; // exist the while loop
                break;
                
            default:
                System.out.println(" You must please enter option(1,2 & 3) if you want to continue"); // handle invalid input -- logic goes here
           
}}
}