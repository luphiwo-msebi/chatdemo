/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author Student
 */
public class Message {
    // Fields - the data a message holds
    private String messageID; // 10-digit auto-generated
    private int    messageNumber; // from loop counter
    private String recipient; // validated cell number
    private String messageText; // max 250 chars
    private String messageHash; // auto-generated
    
    // Constructor
    public Message(int messageNumber, String recipient, String messageText){
        // initialise fields -- logic goes here
        
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
        
    }
    
    // All required methods go here (see Section 4)
    // checkMessageID(), checkRecipientCell(), createMessageHash(),
    // sentMessage(), printMessages(), returnTotalMessages(), storeMessage()

    private String generateMessageID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String createMessageHash() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    // Generate random 10-digit ID
    private String generateMessageID() {
        
        Random random = new Random();
        
        long number = 1000000000L
                + (long)(random.nextDouble() * 9000000000L);
        
        return String.valueOf(number);
        
    }
    
    // Check ID length
    public boolean checkMessageID() {
        
        return messageID.length() <= 10;
   
    }
    
    // Validate recipiet number
    public String checkRecipientCell(){
        
        if (recipient.matches("^\\+\\d{11,12}$")){
            
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct "
            
        }
    }
